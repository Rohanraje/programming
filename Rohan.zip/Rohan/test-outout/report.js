$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Login.feature");
formatter.feature({
  "line": 2,
  "name": "Login",
  "description": "",
  "id": "login",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@Ression_1"
    }
  ]
});
formatter.scenarioOutline({
  "comments": [
    {
      "line": 4,
      "value": "#Background:"
    },
    {
      "line": 5,
      "value": "#Given user is on facebook page"
    },
    {
      "line": 6,
      "value": "#When when user land of fecbook page validate title"
    },
    {
      "line": 7,
      "value": "#And user enters \"techalfalah1@gmail.com\" and \"America121%\" for facebook"
    },
    {
      "line": 8,
      "value": "#Then user click on login button"
    },
    {
      "line": 9,
      "value": "#@regression"
    },
    {
      "line": 10,
      "value": "#without_Example_keyword"
    },
    {
      "line": 11,
      "value": "#S1"
    }
  ],
  "line": 12,
  "name": "user is signing in for facebook",
  "description": "",
  "id": "login;user-is-signing-in-for-facebook",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 13,
  "name": "user is on facebook page",
  "keyword": "Given "
});
formatter.step({
  "line": 14,
  "name": "when user land of fecbook page validate title",
  "keyword": "When "
});
formatter.step({
  "line": 15,
  "name": "user enters \"\u003cusername\u003e\" and \"\u003cpassword\u003e\" for facebook",
  "keyword": "And "
});
formatter.step({
  "line": 16,
  "name": "user click on login button",
  "keyword": "Then "
});
formatter.step({
  "line": 17,
  "name": "user click on messenger icon on facebook home page",
  "keyword": "Then "
});
formatter.step({
  "line": 18,
  "name": "user close the browser",
  "keyword": "Then "
});
formatter.examples({
  "line": 20,
  "name": "",
  "description": "",
  "id": "login;user-is-signing-in-for-facebook;",
  "rows": [
    {
      "cells": [
        "username",
        "password"
      ],
      "line": 22,
      "id": "login;user-is-signing-in-for-facebook;;1"
    },
    {
      "cells": [
        "techalfalah@gmail.com",
        "America121%"
      ],
      "line": 23,
      "id": "login;user-is-signing-in-for-facebook;;2"
    },
    {
      "cells": [
        "BabarDar@gmail.com",
        "Testing123"
      ],
      "line": 24,
      "id": "login;user-is-signing-in-for-facebook;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 23,
  "name": "user is signing in for facebook",
  "description": "",
  "id": "login;user-is-signing-in-for-facebook;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@Ression_1"
    }
  ]
});
formatter.step({
  "line": 13,
  "name": "user is on facebook page",
  "keyword": "Given "
});
formatter.step({
  "line": 14,
  "name": "when user land of fecbook page validate title",
  "keyword": "When "
});
formatter.step({
  "line": 15,
  "name": "user enters \"techalfalah@gmail.com\" and \"America121%\" for facebook",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 16,
  "name": "user click on login button",
  "keyword": "Then "
});
formatter.step({
  "line": 17,
  "name": "user click on messenger icon on facebook home page",
  "keyword": "Then "
});
formatter.step({
  "line": 18,
  "name": "user close the browser",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginwithFreeCRM.user_is_on_facebook_page()"
});
formatter.result({
  "duration": 4439387300,
  "status": "passed"
});
formatter.match({
  "location": "LoginwithFreeCRM.when_user_land_of_fecbook_page_validate_title()"
});
formatter.result({
  "duration": 4899484400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "techalfalah@gmail.com",
      "offset": 13
    },
    {
      "val": "America121%",
      "offset": 41
    }
  ],
  "location": "LoginwithFreeCRM.user_enter_username_and_password_for_facebook(String,String)"
});
formatter.result({
  "duration": 7335866600,
  "status": "passed"
});
formatter.match({
  "location": "LoginwithFreeCRM.login_button()"
});
formatter.result({
  "duration": 5100054300,
  "status": "passed"
});
formatter.match({
  "location": "LoginwithFreeCRM.messenger_icon()"
});
formatter.result({
  "duration": 3229285500,
  "status": "passed"
});
formatter.match({
  "location": "LoginwithFreeCRM.user_close_the_browser()"
});
formatter.result({
  "duration": 152001900,
  "status": "passed"
});
formatter.scenario({
  "line": 24,
  "name": "user is signing in for facebook",
  "description": "",
  "id": "login;user-is-signing-in-for-facebook;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@Ression_1"
    }
  ]
});
formatter.step({
  "line": 13,
  "name": "user is on facebook page",
  "keyword": "Given "
});
formatter.step({
  "line": 14,
  "name": "when user land of fecbook page validate title",
  "keyword": "When "
});
formatter.step({
  "line": 15,
  "name": "user enters \"BabarDar@gmail.com\" and \"Testing123\" for facebook",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 16,
  "name": "user click on login button",
  "keyword": "Then "
});
formatter.step({
  "line": 17,
  "name": "user click on messenger icon on facebook home page",
  "keyword": "Then "
});
formatter.step({
  "line": 18,
  "name": "user close the browser",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginwithFreeCRM.user_is_on_facebook_page()"
});
formatter.result({
  "duration": 3233214600,
  "status": "passed"
});
formatter.match({
  "location": "LoginwithFreeCRM.when_user_land_of_fecbook_page_validate_title()"
});
formatter.result({
  "duration": 3676760400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "BabarDar@gmail.com",
      "offset": 13
    },
    {
      "val": "Testing123",
      "offset": 38
    }
  ],
  "location": "LoginwithFreeCRM.user_enter_username_and_password_for_facebook(String,String)"
});
formatter.result({
  "duration": 7307510800,
  "status": "passed"
});
formatter.match({
  "location": "LoginwithFreeCRM.login_button()"
});
formatter.result({
  "duration": 5095895500,
  "status": "passed"
});
formatter.match({
  "location": "LoginwithFreeCRM.messenger_icon()"
});
formatter.result({
  "duration": 982785600,
  "error_message": "org.openqa.selenium.NoSuchElementException: no such element: Unable to locate element: {\"method\":\"xpath\",\"selector\":\"//*[@id\u003d\u0027navItem_217974574879787\u0027]/a/div\"}\n  (Session info: chrome\u003d81.0.4044.138)\nFor documentation on this error, please visit: https://www.seleniumhq.org/exceptions/no_such_element.html\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027PERSONAL\u0027, ip: \u0027192.168.114.1\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_171\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 81.0.4044.138, chrome: {chromedriverVersion: 81.0.4044.138 (8c6c7ba89cc9..., userDataDir: C:\\Users\\muhammad\\AppData\\L...}, goog:chromeOptions: {debuggerAddress: localhost:50053}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: WINDOWS, platformName: WINDOWS, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify, webauthn:virtualAuthenticators: true}\nSession ID: e6537c92af2c7eb3d92b33b312750004\n*** Element info: {Using\u003dxpath, value\u003d//*[@id\u003d\u0027navItem_217974574879787\u0027]/a/div}\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:187)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:122)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:323)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementByXPath(RemoteWebDriver.java:428)\r\n\tat org.openqa.selenium.By$ByXPath.findElement(By.java:353)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:315)\r\n\tat StepDefinition.LoginwithFreeCRM.messenger_icon(LoginwithFreeCRM.java:130)\r\n\tat ✽.Then user click on messenger icon on facebook home page(Login.feature:17)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "LoginwithFreeCRM.user_close_the_browser()"
});
formatter.result({
  "status": "skipped"
});
});