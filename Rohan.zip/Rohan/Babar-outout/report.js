$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("LastTopic.feature");
formatter.feature({
  "line": 2,
  "name": "Covering multiple below features",
  "description": "",
  "id": "covering-multiple-below-features",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@LastTopic"
    }
  ]
});
formatter.scenario({
  "comments": [
    {
      "line": 3,
      "value": "#\ta. waits (pageload, implicit, explicit)"
    },
    {
      "line": 4,
      "value": "#\tb. isdisplayed, isselected, isenable"
    },
    {
      "line": 5,
      "value": "#\tc. switchto (alert, windowshandles, frame)"
    },
    {
      "line": 6,
      "value": "#\td. Exceptions in selenium"
    }
  ],
  "line": 8,
  "name": "Practicing",
  "description": "",
  "id": "covering-multiple-below-features;practicing",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "User is launching chrome browser for last topic",
  "keyword": "Given "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "#When User is on QAdemoSite practicing waits in selenium"
    },
    {
      "line": 13,
      "value": "#Then User practicing conditions"
    },
    {
      "line": 14,
      "value": "#Then User practicing switchTo in selenium"
    }
  ],
  "line": 15,
  "name": "User Practcing Exceptions in Selenium",
  "keyword": "Then "
});
formatter.match({
  "location": "LastTopic.openBrowser()"
});
formatter.result({
  "duration": 4594451000,
  "status": "passed"
});
formatter.match({
  "location": "LastTopic.Practicing_Exceptions()"
});
formatter.result({
  "duration": 3845530300,
  "error_message": "org.openqa.selenium.NoSuchElementException: no such element: Unable to locate element: {\"method\":\"css selector\",\"selector\":\"#fake\"}\n  (Session info: chrome\u003d81.0.4044.138)\nFor documentation on this error, please visit: https://www.seleniumhq.org/exceptions/no_such_element.html\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027PERSONAL\u0027, ip: \u0027192.168.114.1\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_171\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 81.0.4044.138, chrome: {chromedriverVersion: 81.0.4044.138 (8c6c7ba89cc9..., userDataDir: C:\\Users\\muhammad\\AppData\\L...}, goog:chromeOptions: {debuggerAddress: localhost:61406}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: WINDOWS, platformName: WINDOWS, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify, webauthn:virtualAuthenticators: true}\nSession ID: 61f4034bc745b3620f49f022886c8fc7\n*** Element info: {Using\u003did, value\u003dfake}\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:187)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:122)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:323)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementById(RemoteWebDriver.java:372)\r\n\tat org.openqa.selenium.By$ById.findElement(By.java:188)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:315)\r\n\tat StepDefinition.LastTopic.Practicing_Exceptions(LastTopic.java:174)\r\n\tat ✽.Then User Practcing Exceptions in Selenium(LastTopic.feature:15)\r\n",
  "status": "failed"
});
});