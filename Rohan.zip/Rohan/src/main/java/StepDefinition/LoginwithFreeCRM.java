////package StepDefinition;
//
//import java.util.List;
//
//import org.junit.Assert;
////import static org.junit.Assert.assertEquals;
////
////import org.junit.Assert;
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//
//import cucumber.api.DataTable;
//import cucumber.api.java.Before;
////import cucumber.api.java.After;
////import cucumber.api.java.Before;
//import cucumber.api.java.en.And;
//import cucumber.api.java.en.Given;
//import cucumber.api.java.en.Then;
//import cucumber.api.java.en.When;
//
//public class LoginwithFreeCRM {
//	
//WebDriver driver;
//
////@Before(order=0) //Before class
////public void SetUp() {
////	
////	driver = new ChromeDriver();	
////    driver.navigate().to("https://www.facebook.com/");
////	driver.manage().window().maximize();
////	driver.findElement(By.id("email")).sendKeys("techalfalah1@gmail.com");
////	driver.findElement(By.id("pass")).sendKeys("America121%");
////	driver.findElement(By.id("loginbutton")).click();
////}
////
////@After(order=0) //After class
////public void TearDown() {
////	
////	driver.close();
////	
////	
////}
//
//
//@Before("@First")
////@Given("^user is on messenger page$")
////
////public void user_is_on_messenger_page() {
////	
////	driver.findElement(By.xpath("//*[@id='navItem_217974574879787']/a/div"));
////	
////	
////}
////
////@After("@First")
////@Then("^user click on new message icon$")
////public void Messenger_icon() {
////	
////	
////}
//
//@Given("^user is on facebook page$")
//
//public void user_is_on_facebook_page() {
//	
//	driver = new ChromeDriver();	
//	
//}
//	
//	
//@When("^when user land of fecbook page validate title$")
//public void when_user_land_of_fecbook_page_validate_title()  {
//	
//    driver.navigate().to("https://www.facebook.com/");
//	driver.manage().window().maximize();
//	
//	String ExpectedTitle = "Facebook - Log In or Sign Up";
//	
//	String ActualTitle = driver.getTitle();
//	
//	System.out.println(ActualTitle);
//	
//	Assert.assertEquals(ExpectedTitle, ActualTitle);
//	
//	
//	
//	
//	
//	
//
//}
//
////DataDrivenwithoutExamplesKeyword
//@And("^user enters username and password for facebook$")
//public void user_enter_username_and_password_for_facebook(DataTable credentials ) {
//	
//	List<List<String>> data = credentials.raw();
//   
//   driver.findElement(By.id("email")).sendKeys(data.get(0).get(0));
//   driver.findElement(By.id("pass")).sendKeys(data.get(0).get(1));
//   
//   
//	
//}
//
//
//
////public void user_enters_username_and_password(DataTable credentials){
////	List<List<String>> data = credentials.raw();
////driver.findElement(By.name("username")).sendKeys(data.get(0).get(0));
////driver.findElement(By.name("password")).sendKeys(data.get(0).get(1));
////}
//
//
//
////DataDrivenwithExamplesKeyword
////@And("^user enters \"(.*)\" and \"(.*)\" for facebook$")
////public void user_enter_username_and_password_for_facebook(String username, String password) throws InterruptedException {
////	
////
////   driver.findElement(By.id("email")).sendKeys(username);
////   Thread.sleep(2000);
////   driver.findElement(By.id("pass")).sendKeys(password);
////   Thread.sleep(5000);
//////   String ExpectedCuurentUrl = "";
//////   String currentUrl = driver.getCurrentUrl();
//////   System.out.println(currentUrl);
//////   
//////   Assert.assertEquals(ExpectedCuurentUrl, currentUrl);
////}
//
//
//@Then("^user click on login button$")
//public void login_button() throws InterruptedException {
//	
//	
//	driver.findElement(By.id("loginbutton")).click();
//	Thread.sleep(5000);
//	
//}
//
//@Then("^user click on messenger icon on facebook home page$")
//public void messenger_icon() throws InterruptedException {
//	
//	
//	driver.findElement(By.xpath("//*[@id='navItem_217974574879787']/a/div"));
//	Thread.sleep(3000);
//	
//	String CuurentURL= driver.getCurrentUrl();
//	String ExpectedURL= "https://www.facebook.com/";
//	
//	System.out.println(CuurentURL);
//	
//	Assert.assertEquals(ExpectedURL, CuurentURL);
//}
//
//@Then("^user close the browser$")
//public void user_close_the_browser(){
//
//	driver.close();
//}
//
//@Then("^user click on Messenger button$")
//public void user_on_messenger_page(){
//
//
//}	
//
//@Then("^user click on new message icon$")
//public void user_click_on_messenger_icon(){
//
//	driver.close();
//
//}
//
//
//}
