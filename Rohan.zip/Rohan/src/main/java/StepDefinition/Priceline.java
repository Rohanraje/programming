//package StepDefinition;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//
//import cucumber.api.java.en.Given;
//import cucumber.api.java.en.Then;
//import cucumber.api.java.en.When;
//
//public class Priceline {
//	
//	WebDriver driver;
//	
//	@Given("^User is launching chrome browser$")
//	public void openBrowser() {
//		driver = new ChromeDriver();
//	}
//	
//	@When("^User is on priceline signup window$")
//	public void goToFacebook() {
//		driver.navigate().to("https://www.priceline.com/");
//		driver.manage().window().maximize();
//		driver.findElement(By.id("sign-in-module__anonymous")).click();
//	}
//	
//@Then("User is Signing in with google")
//public void SigningIn_Google() throws InterruptedException {
//	
//	driver.findElement(By.id("signin-view__google-button-top")).click();
//	Thread.sleep(2000);
//	String mainWindow = driver.getWindowHandle();
//	for(String GoogleWindow:driver.getWindowHandles())
//	{
//		driver.switchTo().window(GoogleWindow);
//	}
//	driver.findElement(By.name("identifier")).sendKeys("abc1234@gmail.com");
//	Thread.sleep(2000);
//	driver.close();
//	driver.switchTo().window(mainWindow);
//	
//}
//	
//	
//
//}
