package StepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LastTopic {
	
	
	WebDriver driver;
	
	@Given("^User is launching chrome browser for last topic$")
	public void openBrowser() {
		driver = new ChromeDriver();
	}
	
//	@When("^User is on QAdemoSite practicing waits in selenium$")
//	public void QaDemoSite() throws InterruptedException  {
//		
//		//driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
//		//Thread.sleep(2000);
//		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
//		//1. Dynamic- if time is 10 and page took 2 then its 2 seconds
//		//2. have more options such as hours, days , minutes 
//		
//		//Implicit wait is always declared globally - its for all webelements 
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		//1. Dynamic- if time is 10 and page took 2 then its 2 seconds
//		//2. have more options such as hours, days , minutes 
//		//3. Global
//		
//		
//		driver.navigate().to("http://demo.automationtesting.in/Register.html");
//		driver.manage().window().maximize();
//		
//
//
//	}

//	@Then("^User practicing conditions$")
//	public void Practicing_conditions_inSelenium() throws InterruptedException  {
//      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//	
//		driver.navigate().to("http://demo.automationtesting.in/Register.html");
//		driver.manage().window().maximize();
//		
//		//Conditions
//		//1.  isDisplayed() method is to make sure if the element exist or not
//		boolean b1 = driver.findElement(By.id("submitbtn")).isDisplayed();
//		System.out.println(b1); // if it exist it will give back true else false
//		
//		 boolean b2 = driver.findElement(By.id("Button1")).isDisplayed();
//		 System.out.println(b2);
//		
//		//2.  isEnabled() method is to make sure if the element is enabled or not
//		boolean b3 = driver.findElement(By.id("submitbtn")).isEnabled();
//		System.out.println(b3); // if its enabled it will give back true else false
//	
//		//3.  isSelected() method is only applicable for checkbox, radiobutton and dropdown
//		driver.findElement(By.id("checkbox1")).click(); //checking
//		
//		Thread.sleep(2000);
//		boolean b4 = driver.findElement(By.id("checkbox1")).isSelected();
//		System.out.println(b4);// if its selected then print true
//		
//		driver.findElement(By.id("checkbox1")).click();//unchecking
//		Thread.sleep(2000);
//		
//		boolean b5 = driver.findElement(By.id("checkbox1")).isSelected();
//		System.out.println(b5);// if its not selected then print false
//	
//		driver.close();
//	}
	
	
//	@Then("^User practicing switchTo in selenium$")
//	public void Practicing_SwitchTo() throws InterruptedException {
		
		//Switchto with WindowsHandles method for windows
//		driver.navigate().to("http://demo.automationtesting.in/Windows.html");
//		driver.manage().window().maximize();	
//		
//		driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div[1]/ul/li[2]/a")).click();
//		Thread.sleep(2000);
//		
//		driver.findElement(By.xpath("//*[@id=\"Seperate\"]/button")).click();
//		Thread.sleep(2000);
//		
//		String mainWindow = driver.getWindowHandle();
//		
//		for(String SakinaliumWindow:driver.getWindowHandles())
//		{
//			
//			driver.switchTo().window(SakinaliumWindow);
//			driver.manage().window().maximize();
//		}
//		
//		System.out.println("Printing title of the childwondow" + driver.getTitle());
//		
//		
//		//driver.close();
//		driver.quit();
//		driver.switchTo().window(mainWindow);
		
		
		
		//Switchto method with Alerts
//		driver.navigate().to("http://demo.automationtesting.in/Alerts.html");
//		driver.manage().window().maximize();
//		
//		//Alert for ok
//		driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div[1]/ul/li[1]/a")).click();
//		Thread.sleep(2000);
//		
//		driver.findElement(By.xpath("//*[@id=\"OKTab\"]/button")).click();
//		Thread.sleep(2000);
//		
//		
//		
//		driver.switchTo().alert().accept();
//		Thread.sleep(2000);
//	
//		//Alert for Cancel
//		driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div[1]/ul/li[2]/a")).click();
//		Thread.sleep(2000);
//		
//		driver.findElement(By.xpath("//*[@id=\"CancelTab\"]/button")).click();
//		Thread.sleep(2000);
//		
//		
//		driver.switchTo().alert().dismiss();
//		
//		driver.close();
		
		
		
		//Switchto method with frames
//		driver.navigate().to("http://demo.automationtesting.in/Frames.html");
//		driver.manage().window().maximize();
//		
//		//how to handle frames
//		WebElement frame = driver.findElement(By.id("singleframe"));
//		driver.switchTo().frame(frame);
//		Thread.sleep(2000);
//		
//		driver.findElement(By.xpath("/html/body/section/div/div/div/input")).sendKeys("TestingFrames");
//		Thread.sleep(2000);
//		
//		
//		driver.close();
//		
//		
//	}
	
	
	@Then("^User Practcing Exceptions in Selenium$")
	public void Practicing_Exceptions() throws InterruptedException  {

		driver.navigate().to("http://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		

		try {
			
			driver.findElement(By.id("fake")).click();
				
		}catch (NoSuchElementException e) {

	System.out.println("Element is not found");
		
		Thread.sleep(2000);
		
		throw(e); 
	}
		
		finally {
			
			driver.close();
		}
	
		

	
}
	

}