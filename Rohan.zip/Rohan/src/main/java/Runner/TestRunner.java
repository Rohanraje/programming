package Runner;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions( // to execute stepdefinition and featurefile

		features = "C:\\Users\\muhammad\\eclipse-workspace\\CucumberFeatures\\src\\main\\resources\\Features",
		glue = {"StepDefinition"},
		//format = {"pretty","html:test-outout"},
		plugin = {"pretty","html:Babar-outout"},//output and reporting
		tags = {"@LastTopic"},	
		monochrome = true
		//dryRun = true
		
		)

public class TestRunner {


}

